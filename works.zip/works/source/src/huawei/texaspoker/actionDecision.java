﻿package huawei.texaspoker;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 涓嬫敞鍐崇瓥
 * check | call | raise num | all_in | fold eol
 */
public class actionDecision {
	private List<Card> holeCards=new ArrayList<Card>();
	private List<Card> sharedCards=new ArrayList<Card>();
	private int BB=0;
	private int potSize=0;
	private String lastAction="";
	private int bet=0;
	private int myRestJetton=0;
	public actionDecision( List<Card> holeCards, List<Card> sharedCards ,int bet,int BB,String lastAction,int potSize,int myRestJetton){
		this.holeCards=holeCards;
		this.sharedCards=sharedCards;
		this.bet=bet;
		this.BB=BB;
		this.potSize=potSize;
		this.lastAction=lastAction;
		this.myRestJetton=myRestJetton;
	}
	public String actionSendToServer(){
		pokerPowerAnalysis mPokerPowerAnalysis=new pokerPowerAnalysis(holeCards, sharedCards);
		int pokerRank=mPokerPowerAnalysis.pokerPowerRankValue();//鐗屽姏寮哄害鍊�
		Map<Integer, Integer> numberOfCards = getNumberOfCards(sharedCards);// 鑾峰彇鎵�湁鐗屼腑鐨勪笉鍚屾暟瀛楁暟閲�
		Map<Integer, Integer> suitOfCards = getSuitOfCards(sharedCards);// 鑾峰彇鎵�湁鐗屼腑鐨勮姳鑹叉暟
		int numberOfPairs=0;//鍏卞鏁�
		int numberOfSet=0;//鍏瑂et鏁�
		for(Integer number:numberOfCards.keySet()){
			if(numberOfCards.get(number)==2){
				numberOfPairs++;
			}else{
				if(numberOfCards.get(number)==3){
					numberOfSet++;
				}
			}
		}
		int numberOfSameSuit=0;//鍚岃姳鑹�
		for(Integer number:suitOfCards.keySet()){
			if(suitOfCards.get(number)==3){
				numberOfSameSuit=3;
			}else{
				if(suitOfCards.get(number)==4){
					numberOfSameSuit=4;
					break;
				}
			}
		}
		int oneCardToStraight=0;//鍗曞紶鎴愰『
		//鍗曞紶鎴愰『闈� 涓ゅ紶鎴愰『闈�
		for(int i=2;i<14;i++){
			if(numberOfCards.containsKey(i))continue;
			else{
				numberOfCards.put(i, 1);
				if(getStraight(numberOfCards)>0){
					oneCardToStraight=1;
					break;
				}else{
					numberOfCards.remove(i);
				}
			}
		}
		int twoCardToStraight=0;//涓ゅ紶鎴愰『
		for(int i=2;i<=14;i++){
			if(numberOfCards.containsKey(i))continue;
			else{
				numberOfCards.put(i, 1);
				for(int j=i+1;j<=14;j++){
					if(numberOfCards.containsKey(j))continue;
					else{
						numberOfCards.put(j, 1);
						if(getStraight(numberOfCards)>0){
							twoCardToStraight=1;
						}else{
							numberOfCards.remove(j);
						}
					}
				}
				numberOfCards.remove(i);
			}
		}	
		/**
		 * 鏍规嵁鐗屽瀷鍜屽叕鍏辩墝闈㈡潵鍐冲畾action
		 * 1.鍚岃姳椤� 涓婇『鍗￠『(涓綅涓�/6) raise pot鐨�/2-3/4 涓嬮『(涓綅涓�) check/call  
		 * 2.4鏉�     涓綅涓� 鍒檙aise  pot鐨�/2-3/4   鍚﹀垯 check/fold
		 * 3.钁姦    涓綅涓� 鍒檙aise  pot鐨�/2-3/4   涓綅涓� check/call
		 * 4.鍚岃姳    鑻�鍏叡闈㈡病瀵瑰瓙锛� raise  pot鐨� 1/2  6 check/call  3  check/fold锛夎嫢鍏叡闈㈡湁涓�釜瀵瑰瓙(9 raise/call 6 check/call  3 check/fold) 鍏叡闈㈡湁涓や釜瀵瑰瓙 锛�  check/call 鍏朵粬check/fold锛�
		 * 5.椤哄瓙   鑻ュ叕鍏遍潰鏈夊悓鑺遍潰  3鍚岃壊 check/call锛堣嫢 a.瀵规墜raise骞呭害灏�灏忎簬1/3搴曟睜 call b.鑷繁鍓╀綑绛圭爜涓庡簳姹犵鐮佹瘮渚嬪皬浜�/2 call锛� 4鍚岃壊 check/fold
		 * 		     鑻ュ叕鍏遍潰鏈夊瀛� 1瀵瑰瓙  涓�鍚岃姳闈竴鏍峰鐞�  2瀵瑰瓙涓�鍚岀敾闈竴鏍峰鐞�
		 *        鑻ュ叕鍏遍潰鏈変笁鏉�涓�鍚岃壊涓�牱澶勭悊
		 * 6.涓夋潯    涓庨『瀛愮被浼�
		 * 7.涓ゅ    涓庨『瀛愮被浼�
		 * 8.涓�    涓庨『瀛愮被浼�
		 * 9.楂樼墝    涓庨『瀛愮被浼�
		 */
		if (pokerRank >= 80) {
			// 鍚岃姳椤哄喅绛�
			if (pokerRank % 10 > 3) {
				return "raise " + Math.min(2 * bet + potSize / 2, myRestJetton);
			} else {
				if (pokerRank % 10 == 3) {
					if (bet == 0) {
						return "check";
					} else {
						if (bet < myRestJetton)
							return "call";
						else
							return "all_in";
					}
				} else {
					if (bet == 0) {
						return "check";
					} else {
						return "fold";
					}
				}
			}
		} else {
			// 4鏉″喅绛�
			if (pokerRank >= 70) {
				if (pokerRank % 10 == 9) {
					return "raise "
							+ Math.min(2 * bet + potSize / 2, myRestJetton);
				} else {
					if (bet == 0) {
						return "check";
					} else {
						return "fold";
					}
				}
			} else {
				// 钁姦鍐崇瓥
				if (pokerRank >= 60) {
					if (pokerRank % 10 == 9) {
						return "raise "
								+ Math.min(2 * bet + potSize / 2, myRestJetton);
					} else {
						if (pokerRank % 10 == 6) {
							if (bet == 0) {
								return "check";
							} else {
								if (bet < myRestJetton)
									return "call";
								else
									return "all_in";
							}
						} else {
							if (bet == 0) {
								return "check";
							} else {
								return "fold";
							}
						}
					}
				} else {
					// 鍚岃姳鍐崇瓥
					// 4.鍚岃姳 鑻�鍏叡闈㈡病瀵瑰瓙锛� raise pot鐨�1/2 6 check/call 3
					// check/fold锛夎嫢鍏叡闈㈡湁涓�釜瀵瑰瓙(9 raise/call 6 check/call 3
					// check/fold) 鍏叡闈㈡湁涓や釜瀵瑰瓙 锛� check/call 鍏朵粬check/fold锛�
					if (pokerRank >= 50) {
						if (numberOfPairs == 0 && numberOfSet == 0) {
							if (pokerRank % 10 == 9) {
								return "raise "
										+ Math.min(2 * bet + potSize / 2,
												myRestJetton);
							} else {
								if (pokerRank % 10 == 6) {
									if (bet == 0) {
										return "check";
									} else {
										if (bet < myRestJetton)
											return "call";
										else
											return "all_in";
									}
								} else {
									if (bet == 0) {
										return "check";
									} else {
										return "fold";
									}
								}
							}
						} else {
							// 涓�釜鍏叡瀵规椂 75%鐨勬椂鍊檙aise
							if (numberOfPairs == 1) {
								if (pokerRank % 10 == 9) {
									double a = Math.random();
									if (a > 0.6) {
										return "raise "
												+ Math.min(2 * bet + potSize
														/ 2, myRestJetton);
									}else{
										if(bet==0) return "check";
										if (bet < myRestJetton)
											return "call";
										else
											return "all_in";
									}
								}else {
										if (pokerRank % 10 == 6) {
											if (bet == 0) {
												return "check";
											} else {
												// 绛圭爜灏忎簬3BB 鎴栬� 绛圭爜涓庡簳姹犳瘮渚�/3浠ヤ笅灏辫窡娉�
												// 鍚﹀垯寮冪墝
												if (bet > potSize / 2
														&& myRestJetton > potSize / 3
														&& myRestJetton >= 3 * BB) {
													return "fold";
												} else {
													if (bet < myRestJetton)
														return "call";
													else
														return "all_in";
												}

											}
										} else {
											//寮辩墝寮冪墝
											if (bet == 0) {
												return "check";
											} else {
												return "fold";
											}
										}
									}							
							} else {
								if (numberOfPairs == 2 || numberOfSet > 0) {
									if (bet == 0) {
										return "check";
									} else {
										// 濡傛灉鏄皬鍔犳敞 鍒欒窡浣�鍚﹀垯寮冪墝
										if (bet < Math.min(3 * BB, potSize / 4)) {
											return "call";
										}
										return "fold";
									}
								}
							}
						}
					} else {
						// 椤哄瓙鍐崇瓥
						if (pokerRank >= 40) {
							if (numberOfPairs == 0 && numberOfSet == 0
									&& numberOfSameSuit < 3) {
								if (pokerRank % 10 == 9) {
									return "raise "
											+ Math.min(2 * bet + potSize / 2,
													myRestJetton);
								} else {
									if (pokerRank % 10 == 6) {
										if (bet == 0) {
											return "check";
										} else {
											if (bet < myRestJetton)
												return "call";
											else
												return "all_in";
										}
									} else {
										if (bet == 0) {
											return "check";
										} else {
											return "fold";
										}
									}
								}
							} else {
								// 涓�釜鍏叡瀵�鎴栬�鏄姳闈㈡椂 50%鐨勬椂鍊檙aise
								if (numberOfPairs == 1 || numberOfSameSuit == 3) {
									if (pokerRank % 10 == 9) {
										double a = Math.random();
										if (a > 0.6) {
											return "raise "
													+ Math.min(2 * bet
															+ potSize / 2,
															myRestJetton);
										}
										else{
											if(bet==0) return "check";
											if (bet < myRestJetton)
												return "call";
											else
												return "all_in";
										}
									}else {
											if (pokerRank % 10 == 6) {
												if (bet == 0) {
													return "check";
												} else {
													// 绛圭爜灏忎簬3BB 鎴栬�
													// 绛圭爜涓庡簳姹犳瘮渚�/3浠ヤ笅灏辫窡娉�鍚﹀垯寮冪墝
													if (bet > potSize / 2
															&& myRestJetton > potSize / 3
															&& myRestJetton >= 3 * BB) {
														return "fold";
													} else {
														 
														if (bet < myRestJetton)
															return "call";
														else
															return "all_in";
													}

												}
											} else {
												if (bet == 0) {
													return "check";
												} else {
													return "fold";
												}
											}
										
									}
								} else {
									if (numberOfPairs == 2 || numberOfSet > 0
											|| numberOfSameSuit == 4) {
										if (bet == 0) {
											return "check";
										} else {
											// 濡傛灉鏄皬鍔犳敞 鍒欒窡浣�鍚﹀垯寮冪墝
											if (bet < Math.min(3 * BB,
													potSize / 4)) {
												return "call";
											}
											return "fold";
										}
									} else {
										if (bet == 0) {
											return "check";
										} else
										return "fold";
									}
								}
							}
						} else {
							// 涓夋潯鍐崇瓥
							/**
							 * set鐗屽姏鍒嗘瀽
							 * 1.鏆�   鎵嬬墝涓ゅ紶閮芥槸triNumber 銆愪釜浣嶇疆涓�銆�
							 * 2.鏄�   鎵嬬墝鍙湁涓�紶鏄�triNumber 銆愪釜浣嶇疆涓�銆�
							 * 3.闈�   鍏叡鐗屾槸3寮�鎵嬬墝鏄珮鐗孉  銆愪釜浣嶇疆涓�銆�
							 * 4.闈igh  銆愪釜浣嶇疆涓�銆�
							 */
							if (pokerRank >= 30) {
								if(numberOfSameSuit<3&&oneCardToStraight==0){
									if(pokerRank%10==9){
										return "raise "
												+ Math.min(2 * bet
														+ potSize / 2,
														myRestJetton);
									}else{
										if(pokerRank%10==6){
											
												if(bet==0)return "check";
												if (bet < myRestJetton)
													return "call";
												else
													return "all_in";
										
											
										}else{
											if (bet == 0) {
												return "check";
											} else {
												return "fold";
											}
										}
									}
								}else{
									if(oneCardToStraight==1||numberOfSameSuit==4){
										if (bet > potSize / 2
												&& myRestJetton > potSize / 3
												&& myRestJetton >= 3 * BB) {
											return "fold";
										} else {
											if(bet==0)return "check";
											if (bet < myRestJetton)
												return "call";
											else
												return "all_in";
										}
									}else{
										//TODO
										if (pokerRank % 10 == 9) {
											double a = Math.random();
											if (a > 0.6) {
												return "raise "
														+ Math.min(2 * bet
																+ potSize / 2,
																myRestJetton);
											}
											else{
												if(bet==0)return "check";
												if (bet < myRestJetton)
													return "call";
												else
													return "all_in";
											}
										}else {
												if (pokerRank % 10 == 6) {
													if (bet == 0) {
														return "check";
													} else {
														// 绛圭爜灏忎簬3BB 鎴栬�
														// 绛圭爜涓庡簳姹犳瘮渚�/3浠ヤ笅灏辫窡娉�鍚﹀垯寮冪墝
														if (bet > potSize / 2
																&& myRestJetton > potSize / 3
																&& myRestJetton >= 3 * BB) {
															return "fold";
														} else {
															if (bet < myRestJetton)
																return "call";
															else
																return "all_in";
														}

													}
												} else {
													if (bet == 0) {
														return "check";
													} else {
														return "fold";
													}
												}
											
										}			
									}

								}	
							} else {
								// 涓ら槦鍐崇瓥
								if (pokerRank >= 20) {
									if(numberOfSameSuit<3&&oneCardToStraight==0){
										if(pokerRank%10==9){
											return "raise "
													+ Math.min(2 * bet
															+ potSize / 2,
															myRestJetton);
										}else{
											if(pokerRank%10==6){
												
													if(bet==0)return "check";
													if (bet < myRestJetton)
														return "call";
													else
														return "all_in";
											
												
											}else{
												if (bet == 0) {
													return "check";
												} else {
													return "fold";
												}
											}
										}
									}else{
										if(oneCardToStraight==1||numberOfSameSuit==4){
											if (bet > potSize / 2
													&& myRestJetton > potSize / 3
													&& myRestJetton >= 3 * BB) {
												return "fold";
											} else {
												if(bet==0)return "check";
												if (bet < myRestJetton)
													return "call";
												else
													return "all_in";
											}
										}else{
											//TODO
											if (pokerRank % 10 == 9) {
												double a = Math.random();
												if (a > 0.6) {
													return "raise "
															+ Math.min(2 * bet
																	+ potSize / 2,
																	myRestJetton);
												}
												else{
													if(bet==0)return "check";
													if (bet < myRestJetton)
														return "call";
													else
														return "all_in";
												}
											}else {
													if (pokerRank % 10 == 6) {
														if (bet == 0) {
															return "check";
														} else {
															// 绛圭爜灏忎簬3BB 鎴栬�
															// 绛圭爜涓庡簳姹犳瘮渚�/3浠ヤ笅灏辫窡娉�鍚﹀垯寮冪墝
															if (bet > potSize / 2
																	&& myRestJetton > potSize / 3
																	&& myRestJetton >= 3 * BB) {
																return "fold";
															} else {
																if (bet < myRestJetton)
																	return "call";
																else
																	return "all_in";
															}

														}
													} else {
														if (bet == 0) {
															return "check";
														} else {
															return "fold";
														}
													}
												
											}			
										}

									}	
								} else {
									// 涓�鍐崇瓥
									if (pokerRank >= 10) {
										if(numberOfSameSuit<3&&oneCardToStraight==0){
											if(pokerRank%10==9){
												return "raise "
														+ Math.min(2 * bet
																+ potSize / 2,
																myRestJetton);
											}else{
												if(pokerRank%10==6){
													
													
														if(bet==0)return "check";
														if (bet < myRestJetton)
															return "call";
														else
															return "all_in";
													
													
												}else{
													if (bet == 0) {
														return "check";
													} else {
														return "fold";
													}
												}
											}
										}else{
											if(oneCardToStraight==1||numberOfSameSuit==4){
												if (bet > potSize / 2
														&& myRestJetton > potSize / 3
														&& myRestJetton >= 3 * BB) {
													return "fold";
												} else {
													if(bet==0)return "check";
													if (bet < myRestJetton)
														return "call";
													else
														return "all_in";
												}
											}else{
												//TODO
												if (pokerRank % 10 == 9) {
													
													
														if(bet==0)return "check";
														if (bet < myRestJetton)
															return "call";
														else
															return "all_in";
													
												}else {
														if (pokerRank % 10 == 6) {
															if (bet == 0) {
																return "check";
															} else {
																// 绛圭爜灏忎簬3BB 鎴栬�
																// 绛圭爜涓庡簳姹犳瘮渚�/3浠ヤ笅灏辫窡娉�鍚﹀垯寮冪墝
																if (bet > potSize / 2
																		&& myRestJetton > potSize / 3
																		&& myRestJetton >= 3 * BB) {
																	return "fold";
																} else {
																	if (bet < myRestJetton)
																		return "call";
																	else
																		return "all_in";
																}

															}
														} else {
															if (bet == 0) {
																return "check";
															} else {
																return "fold";
															}
														}
													
												}			
											}
										}	
									} else {
										// 楂樼墝鍐崇瓥锛堝寘鍚�鍚勭鍚墝缁勫悎锛�
										if (pokerRank % 10 == 9) {
											return "raise "
													+ Math.min(2 * bet + potSize / 2, myRestJetton);
										} else {
											if (pokerRank % 10 == 6) {
												if (bet == 0) {
													return "raise "+ Math.min(2 * bet + potSize / 2, myRestJetton);
												} else {
													if(bet<potSize*1/2){
														if (bet < myRestJetton)
															return "call";
														else
															return "all_in";
													}else{
														return "fold";
													}
													
												}
											} else {
												if (bet == 0) {
													return "check";
												} else {
													return "fold";
												}
											}
										}
																				
									}
								}
							}
						}
					}
				}
			}

		}

		return "check";
	}

	// 鍒ゆ柇鍏叡鐗屾槸鍚﹀瓨鍦ㄥ惉椤洪潰锛堝崟寮犳垚椤�鍙屽紶鎴愰『锛�
	public int getStraight(Map<Integer, Integer> numberOfCards) {
		if (numberOfCards.size() <= 4)
			return 0;
		int[] aAsNormal = new int[numberOfCards.size()];
		int index = 0;
		boolean hasAcard = false;
		for (Integer number : numberOfCards.keySet()) {
			if (number == 14)
				hasAcard = true;
			aAsNormal[index] = number;
			index++;
		}
		Arrays.sort(aAsNormal);
		int preNumber = aAsNormal[0];
		int count = 0;
		int Flag_end = 0;// 鏈夐『瀛愮殑鏍囧織 瀛樺偍椤哄瓙鐨勬渶澶т綅缃�
		for (int i = 0; i < index; i++) {
			if (aAsNormal[i] - preNumber == 1)
				count++;
			else {
				if (count >= 4) {
					Flag_end = i;
				}
				count = 0;
			}
			if (count >= 4) {
				Flag_end = i;
			}
			preNumber = aAsNormal[i];
		}
		if (Flag_end != 0) {
			return 44;

		}
		// 鏈堿鐨勬儏鍐�
		if (hasAcard) {
			int[] aAs1 = new int[7];
			index = 0;
			for (Integer number : numberOfCards.keySet()) {
				if (number == 14)
					number = 1;
				aAs1[index] = number;
				index++;
			}
			Arrays.sort(aAs1);
			preNumber = aAs1[0];
			count = 0;
			Flag_end = 0;
			for (int i = 0; i < index; i++) {
				if (aAs1[i] - preNumber == 1)
					count++;
				else {
					if (count >= 4)
						Flag_end = i;
					count = 0;
				}
				if (count >= 4)
					Flag_end = i;
				preNumber = aAs1[i];

			}
			if (Flag_end != 0) {
				return 44;
			}
		}
		return 0;
	}
	public int getStraightNumber(Map<Integer, Integer> numberOfCards) {
		if (numberOfCards.size() < 4)
			return 0;
		int[] aAsNormal = new int[numberOfCards.size()];
		int index = 0;
		boolean hasAcard = false;
		for (Integer number : numberOfCards.keySet()) {
			if (number == 14)
				hasAcard = true;
			aAsNormal[index] = number;
			index++;
		}
		Arrays.sort(aAsNormal);
		int preNumber = aAsNormal[0];
		int count = 0;
		int Flag_end = 0;// 鏈夐『瀛愮殑鏍囧織 瀛樺偍椤哄瓙鐨勬渶澶т綅缃�
		for (int i = 0; i < index; i++) {
			if (aAsNormal[i] - preNumber == 1)
				count++;
			else {
				if (count >= 3) {
					Flag_end = i;
				}
				count = 0;
			}
			if (count >= 3) {
				Flag_end = i;
			}
			preNumber = aAsNormal[i];
		}
		if (Flag_end != 0) {
			int[] straightComnbs = new int[4];// 瀛樺偍椤哄瓙鐗�
			for (int i = 0; i < 4; i++) {
				straightComnbs[i] = aAsNormal[Flag_end - 4+i];
			}
			
		}
		// 鏈堿鐨勬儏鍐�
		if (hasAcard) {
			int[] aAs1 = new int[7];
			index = 0;
			for (Integer number : numberOfCards.keySet()) {
				if (number == 14)
					number = 1;
				aAs1[index] = number;
				index++;
			}
			Arrays.sort(aAs1);
			preNumber = aAs1[0];
			count = 0;
			Flag_end = 0;
			for (int i = 0; i < index; i++) {
				if (aAs1[i] - preNumber == 1)
					count++;
				else {
					if (count >= 3)
						Flag_end = i;
					count = 0;
				}
				if (count >= 3)
					Flag_end = i;
				preNumber = aAs1[i];

			}
			if (Flag_end != 0) {
				int[] straightComnbs = new int[4];// 瀛樺偍椤哄瓙鐗�
				for (int i = 0; i < 4; i++) {
					straightComnbs[i] = aAsNormal[Flag_end - 4+i];
				}
			}
		}
		return 0;
	}
	public Map<Integer, Integer> getNumberOfCards(List<Card> cards) {
		Map<Integer, Integer> res = new HashMap<Integer, Integer>();
		for (Card card : cards) {
			if (res.containsKey(card.number)) {
				res.put(card.number, res.get(card.number) + 1);
			} else
				res.put(card.number, 1);
		}
		return res;
	}

	public Map<Integer, Integer> getSuitOfCards(List<Card> cards) {
		Map<Integer, Integer> res = new HashMap<Integer, Integer>();
		for (Card card : cards) {
			if (res.containsKey(card.suit)) {
				res.put(card.suit, res.get(card.suit) + 1);
			} else
				res.put(card.suit, 1);
		}
		return res;
	}
}
