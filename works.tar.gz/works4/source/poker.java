public class poker{
	int num;
	public poker(int num){
		this.num=num;
	}
}
