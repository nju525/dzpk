import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.List;


public class Game {
	Socket socket;
	PrintWriter send2server;
	BufferedReader reader;
	String head;
	int BigBlind,Bet,bet_in;
	int id;
	List<poker> privatePoker=new ArrayList<poker>();
	public static void main(String[] args) throws IOException {
		Game thnju=new Game();
		/*args=new String[5];
		args[0]="127.0.0.1";
		args[1]="8888";
		args[2]="127.0.0.1";
		args[3]="8989";
		args[4]="7777";*/
		thnju.id=Integer.parseInt(args[4]);
		
		
		try {
			thnju.connect(args);
			thnju.send2server=new PrintWriter(thnju.socket.getOutputStream());
			thnju.reader=new BufferedReader(new InputStreamReader(thnju.socket.getInputStream()));
			thnju.sendMsg(thnju.send2server, "reg: "+thnju.id+" THNJU ");
			
			while(true){
				do{
					thnju.receiveMsg(thnju.reader);
					
				}while(!thnju.head.equals("pot-win")&&!thnju.head.equals("game-over "));
				if(thnju.head.equals("game-over "))
					break ;
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			thnju.socket.close();
			thnju.reader.close();
		}
	
	}
	private void receiveMsg(BufferedReader reader) {
		// TODO Auto-generated method stub
		try {
			String headtmp=reader.readLine();			
			if(headtmp.equals("game-over ")){
				this.head=headtmp;
				return;
			}	
			headtmp=headtmp.substring(0, headtmp.indexOf("/"));
			this.head=new String(headtmp);
			headtmp="/"+headtmp+" ";
			for(String body=reader.readLine();!body.equals(headtmp);body=reader.readLine()){
				if(head.equals("blind")){
					String temp=body,msg="";
					do{
						msg+=temp;
					}
					while(!(temp=reader.readLine()).equals(headtmp));
					String a[]=msg.split(":");
					if(a.length==3){//�д�ä
						BigBlind=Integer.parseInt(a[2].trim());
					}
					else{//�޴�ä
						BigBlind=Integer.parseInt(a[1].trim());
					}
					break;
				}
				else if(head.equals("hold")){
					String temp=body,msg="";
					do{
						msg+=temp;
					}
					while(!(temp=reader.readLine()).equals(headtmp));
					String msgarray[]=msg.split(" ");
					for(int i=1;i<msgarray.length;i=i+2){
						privatePoker.add(new poker(pokerpoint2num(msgarray[i])));
					}
					/*for(poker p:privatePoker)
						System.out.println("�������ƣ�"+p.num);*/
					break;
				}
				else if(head.equals("inquire")){
					String temp=body,msg="";
					do{
						msg+=temp+"$";
					}
					while(!(temp=reader.readLine()).equals(headtmp));
					Bet=getBet(msg);
					sendMsg(send2server, twoPokers(BigBlind, Bet));	
					break;			
				}
				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private int getBet(String msg) {
		String msgarray[]=msg.split("\\$");
		int bet=0;
		int ll=msgarray.length-1;
		String myMsg=msgarray[ll];
		while(myMsg==null){
			--ll;
			myMsg=msgarray[ll];
		}
		String split[]=myMsg.split(" ");
		if(split[0].equals(id+"")){
			bet_in=new Integer(split[3]);
		}
		for(int i=0;i<msgarray.length&&msgarray[i]!=null;i++){
			split=msgarray[i].split(" ");
			if(split[4].equals("blind")||split[4].equals("call")
					||split[4].equals("raise")||split[4].equals("all_in")){
				bet=new Integer(split[3])-bet_in;
				break;
			}
			else if(split[4].equals("check")){
				bet=0;
				break;
			}
		}		
		return bet<0?0:bet;
	}
	private void connect(String args[]) throws IOException{
		boolean connected=false;
		while(!connected){
			try {
				SocketAddress serveraddress = new InetSocketAddress(
						args[0], Integer.parseInt(args[1]));
				SocketAddress hostaddress = new InetSocketAddress(args[2],
						Integer.parseInt(args[3]));
				socket = new Socket();
				socket.setReuseAddress(true);
				socket.bind(hostaddress);//�󶨿ͻ��˵�ָ��IP�Ͷ˿ں�
				socket.connect(serveraddress);
				connected=true;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}				
				continue;			
			}//����server
		}
	}
	public void sendMsg(PrintWriter send2server,String context){
		send2server.println(context);
		send2server.flush();
	}
	private int pokerpoint2num(String pokerpoint){
		int num=0;
		try{
			num=new Integer(pokerpoint).intValue();
		}
		catch (IllegalArgumentException e){
			if(pokerpoint.equals("A"))
				num=14;
			else if(pokerpoint.equals("J"))
				num=11;
			else if(pokerpoint.equals("Q"))
				num=12;
			else if(pokerpoint.equals("K"))
				num=13;
		}
		return num;
	}
	
	
	
/*	 class poker {
		public  int num;//���� 1-13 ||A=14 J=11 Q=12 K=13
		public poker(int num){
			this.num=num;
		}
	}*/
	
	public String twoPokers(int BB,int bet){
		int[][] table={
				{3,0,0,0,0,0,0,0,0,0,0,0,0},
				{2,3,0,0,0,0,0,0,0,0,0,0,0},
				{2,2,3,0,0,0,0,0,0,0,0,0,0},
				{2,1,1,2,0,0,0,0,0,0,0,0,0},
				{1,1,1,1,2,0,0,0,0,0,0,0,0},
				{1,1,1,1,1,1,0,0,0,0,0,0,0},
				{1,1,1,0,0,1,1,0,0,0,0,0,0},
				{1,1,1,0,0,0,1,1,0,0,0,0,0},
				{1,1,0,0,0,0,0,0,1,0,0,0,0},
				{1,1,0,0,0,0,0,0,0,1,0,0,0},
				{1,0,0,0,0,0,0,0,0,0,1,0,0},
				{1,0,0,0,0,0,0,0,0,0,0,1,0},
				{1,0,0,0,0,0,0,0,0,0,0,0,1},		
		};
		int big=Math.max(privatePoker.get(0).num, privatePoker.get(1).num);
		int small=Math.min(privatePoker.get(0).num, privatePoker.get(1).num);
		int value=table[14-small][14-big];
		if(value==3){
			return "raise "+3*BB;
		}else{
			if(value==2){
				if(bet<=2*BB){
					return "raise "+2*BB;
				}else{
					return "fold";
				}
			}else{
				if(value==1){
					if(bet<=BB){
						return "raise "+2*BB;
					}else{
						return "fold";
					}
				}else{
					return "fold";
				}				
			}
		}
	}
	public String after(int BB,int bet){
		if(bet==0){
			return "raise "+BB;
		}else{
			return "fold";
		}
	}
	
}
